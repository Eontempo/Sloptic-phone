// Backend logic smoke test. Uses small transport stubs so tests run without installing packages.
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const actualRequire = require;
const handlers = {};
const received = {};
class FakeIO {
  constructor() {this.sockets={sockets:new Map()};this.connection=null;}
  on(name,handler){if(name==='connection')this.connection=handler;}
  to(id){return {emit:(name,payload)=>{(received[id] ||= []).push({name,payload});}};}
}
let io;
const fakeExpress = function(){return {use(){},get(){},post(){}};};
fakeExpress.static=()=>()=>{};
const fakeMulter=function(){return {single(){return (req,res,cb)=>cb();}};};
fakeMulter.diskStorage=()=>({});
function makeSocket(id){
  const events={};
  const obj={id,data:{},on(name,cb){events[name]=cb;},join(){},to(){return {emit(){}};},
    emit(name,payload){(received[id] ||= []).push({name,payload});},
    disconnect(){if(events.disconnect)events.disconnect();}
  };
  io.sockets.sockets.set(id,obj);io.connection(obj);
  obj.send=(name,payload={})=>{let ack;events[name](payload,response=>{ack=response;});return ack;};
  return obj;
}
const source=fs.readFileSync(path.resolve(__dirname,'../server.js'),'utf8');
const context={
  require(name){
    if(name==='express')return fakeExpress;
    if(name==='multer')return fakeMulter;
    if(name==='socket.io')return {Server:class extends FakeIO{constructor(){super();io=this;}}};
    if(name==='http')return {createServer:()=>({listen(){}})};
    return actualRequire(name);
  },
  __dirname:path.resolve(__dirname,'..'), process, Buffer, Date, console,
  setInterval(){}, setTimeout(){}, clearInterval(){}
};
vm.runInNewContext(source,context,{filename:'server.js'});
const ids=['11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222','33333333-3333-4333-8333-333333333333'];
const names=['Ari','Bea','Cai'];
const tokens=['aaaaaaaa-1111-4111-8111-111111111111','bbbbbbbb-2222-4222-8222-222222222222','cccccccc-3333-4333-8333-333333333333'];
const clients=ids.map((_,i)=>makeSocket(`sock${i}`));
const created=clients[0].send('room:create',{name:names[0],clientId:ids[0],authToken:tokens[0]});
assert.equal(created.ok,true);const code=created.code;assert.equal(code.length,6);
for(let i=1;i<3;i++)assert.equal(clients[i].send('room:join',{name:names[i],clientId:ids[i],authToken:tokens[i],code}).ok,true);
assert.equal(clients[0].send('room:mode',{minutes:10}).ok,true);
assert.equal(clients[1].send('room:mode',{minutes:5}).ok,false);
for(let i=0;i<3;i++)assert.equal(clients[i].send('room:role',{role:['Artist 1','Artist 2','Composer'][i]}).ok,true);
assert.equal(clients[0].send('room:start').ok,true);
function state(i){return [...(received['sock'+i]||[])].reverse().find(e=>e.name==='room:state').payload;}
assert.equal(state(0).phase,'planning');
assert.equal(state(0).recipient.id,ids[1]);
assert.equal(state(1).recipient.id,ids[2]);
assert.equal(state(2).recipient.id,ids[0]);
for(let i=0;i<2;i++)assert.equal(clients[i].send('planning:submit',{prompt:`Original idea ${i}`}).ok,true);
assert.equal(state(0).phase,'planning');
assert.equal(clients[2].send('planning:submit',{prompt:'Original idea 2'}).ok,true);
assert.equal(state(0).phase,'creation');
assert.equal(state(0).myPrompt,'Original idea 2');
assert.equal(state(1).myPrompt,'Original idea 0');
const actionId='44444444-4444-4444-8444-444444444444';
clients[0].send('draw:op',{type:'dot',actionId,color:'#ff0000',opacity:.5,size:12,x:50,y:60});
assert.equal(clients[0].send('draw:undo').ok,true);
assert.equal(state(0).canvasOps.length,0);
assert.equal(clients[0].send('draw:redo').ok,true);
assert.equal(state(0).canvasOps.length,1);
// A composer can only submit after uploading an MP3 through the HTTP endpoint.
assert.equal(clients[2].send('creation:submit').ok,false);
assert.equal(clients[0].send('creation:submit').ok,true);
assert.equal(clients[1].send('creation:submit').ok,true);
// Use the server's room map to simulate a completed MP3 upload in the transport-free test.
vm.runInNewContext(`rooms.get(${JSON.stringify(code)}).audio={url:'/uploads/test.mp3',name:'test.mp3',size:1024}`,context);
assert.equal(clients[2].send('creation:submit').ok,true);
assert.equal(state(0).phase,'results');
for(let v=0;v<3;v++)for(let t=0;t<3;t++)assert.equal(clients[v].send('rating:vote',{targetId:ids[t],stars:5}).ok,true);
assert.equal(state(0).scores[0].total,15);
assert.equal(state(0).scores[0].mvp,true);
for(let i=0;i<3;i++)assert.equal(clients[i].send('room:finish').ok,true);
assert.equal(state(0).phase,'lobby');
assert.equal(state(0).modeMinutes,null);
for(let i=0;i<3;i++)assert.equal(clients[i].send('room:role',{role:['Artist 1','Artist 2','Composer'][i]}).ok,true);
assert.equal(clients[0].send('room:mode',{minutes:5}).ok,true);
assert.equal(clients[0].send('room:start').ok,true);
assert.equal(state(0).recipient.id,ids[2]); // prompt recipient alternates every round
console.log('PASS — rooms, roles, mode, prompt rotation, phases, undo/redo, composer lock, ratings/MVP, reset');
