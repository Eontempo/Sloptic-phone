// Template smoke test without a browser or third-party packages.
'use strict';
const fs=require('fs');const path=require('path');const vm=require('vm');const assert=require('assert');
const app={innerHTML:'',querySelector(){return null;}};
const toasts={append(){}};
const fakeContext={globalAlpha:1,fillStyle:'#ffffff',fillRect(){},drawImage(){},save(){},restore(){},beginPath(){},arc(){},fill(){},moveTo(){},lineTo(){},stroke(){},getImageData(){return{data:new Uint8ClampedArray(4)};},putImageData(){}};
const document={
 querySelector(s){if(s==='#app')return app;if(s==='#toasts')return toasts;return null;},
 querySelectorAll(){return [];},
 createElement(tag){if(tag==='canvas')return {width:0,height:0,getContext(){return fakeContext;}};return{style:{},append(){},remove(){}};}
};
const listeners={};
const socket={connected:true,on(name,fn){listeners[name]=fn;},timeout(){return this;},emit(){}};
const storage={getItem(){return null;},setItem(){},removeItem(){}};
const location={search:'',origin:'http://localhost:3000'};
const context={document,window:{addEventListener(){}},location,URLSearchParams,localStorage:storage,sessionStorage:storage,
  crypto:require('crypto').webcrypto,io:()=>socket,Date,setInterval(){},setTimeout(){},navigator:{},performance:{now:()=>0},
  console,FormData:class{},Math,Number,String,Array,Uint8Array,Uint8ClampedArray,Promise,parseInt,Error};
const code=fs.readFileSync(path.resolve(__dirname,'../public/app.js'),'utf8');
vm.runInNewContext(code,context,{filename:'app.js'});
assert(app.innerHTML.includes('Create a room'),'Landing page should render');
const ids=['11111111-1111-4111-8111-111111111111','22222222-2222-4222-8222-222222222222','33333333-3333-4333-8333-333333333333'];
const players=ids.map((id,i)=>({id,name:['Remy','River','Sky'][i],role:['Artist 1','Artist 2','Composer'][i],online:true,isHost:i===0,promptSubmitted:false,created:false,finished:false}));
const makeState=(phase,i)=>({code:'SLOPTY',phase,modeMinutes:10,hostId:ids[0],myId:ids[i],serverNow:Date.now(),deadline:Date.now()+60000,round:1,
 players,recipient:{name:players[(i+1)%3].name,role:players[(i+1)%3].role},myPrompt:'A giant cat in space',partnerPrompt:'Sailing avocado',partnerName:'River',
 mySubmittedPrompt:'Funny flying banana',audio:null,artwork:null,ratings:{},ratingsComplete:0,videoExport:false,scores:players.map(p=>({id:p.id,total:0,votes:0,mvp:false})),canvasOps:[]});
for(const [phase,index,text] of [['lobby',0,'creative crew'],['planning',0,'creative challenge'],['creation',0,'SHARED MASTERPIECE'],['creation',2,'Put your music in me'],['results',0,'FINAL MASTERPIECE']]){
 listeners['room:state'](makeState(phase,index));
 assert(app.innerHTML.toLowerCase().includes(text.toLowerCase()),`${phase}/${index} render is missing ${text}`);
}
console.log('PASS — landing, lobby, planning, artist, composer, and results templates render');
